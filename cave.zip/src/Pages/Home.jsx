import React from 'react'
import Header from '../Components/Layout/Header/Header'
import Testing from './Testing'
import Featured from '../Components/Layout/Featured/Featured'

const Home = () => {
    return (
        <>  

            <Testing />
            <Featured/>


        </>
    )
}

export default Home